﻿namespace Ecommerce.Api.AppSetting
{
    public class AppSetting
    {
    }
}
