﻿namespace Ecommerce.Api
{
    public class KeyVaultCache
    {
    }
}
